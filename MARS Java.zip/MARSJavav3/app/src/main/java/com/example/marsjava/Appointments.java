package com.example.marsjava;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Appointments extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_appointments);
    }
}